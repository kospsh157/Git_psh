저를 write3.txt로 보내주세요.
